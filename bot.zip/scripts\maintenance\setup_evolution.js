const axios = require('axios');
const fs = require('fs');

const API_URL = 'http://localhost:8080';
const API_KEY = '429683C4C977415CAAFCCE10F7D57E11';
const INSTANCE_NAME = 'FinanceBot';

const client = axios.create({
    baseURL: API_URL,
    headers: {
        'apikey': API_KEY,
        'Content-Type': 'application/json'
    }
});

async function run() {
    try {
        console.log("🔍 Checking instances...");
        const instances = await client.get('/instance/fetchInstances');
        const exists = instances.data.find(i => i.name === INSTANCE_NAME || i.instance?.instanceName === INSTANCE_NAME);

        if (!exists) {
            console.log(`⚠️ Instance '${INSTANCE_NAME}' not found. Creating...`);
            await client.post('/instance/create', {
                instanceName: INSTANCE_NAME,
                qrcode: true,
                integration: "WHATSAPP-BAILEYS"
            });
            console.log("✅ Instance created.");
        } else {
            console.log(`✅ Instance '${INSTANCE_NAME}' already exists.`);
        }

        console.log("🔄 Fetching QR Code...");
        // Call connect to ensure session is active/get QR
        const connectRes = await client.get(`/instance/connect/${INSTANCE_NAME}`);

        let base64 = null;
        if (connectRes.data && connectRes.data.base64) {
            base64 = connectRes.data.base64;
        } else if (connectRes.data && connectRes.data.qrcode && connectRes.data.qrcode.base64) {
            base64 = connectRes.data.qrcode.base64;
        }

        if (base64) {
            const html = `
            <html>
                <body style="display:flex;justify-content:center;align-items:center;height:100vh;background:#f0f0f0;">
                    <div style="text-align:center;">
                        <h1>Escaneie este QR Code</h1>
                        <img src="${base64}" style="box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px;" />
                        <p>Use o WhatsApp > Aparelhos Conectados > Conectar Aparelho</p>
                    </div>
                </body>
            </html>
            `;
            fs.writeFileSync('qrcode.html', html);
            console.log("🎉 QR Code saved to 'qrcode.html'.");
        } else {
            console.log("ℹ️ No QR Code returned. Instance might be already connected or starting.");
            console.log("Response:", JSON.stringify(connectRes.data, null, 2));
        }

    } catch (error) {
        console.error("❌ Error:", error.response?.data || error.message);
    }
}

run();
