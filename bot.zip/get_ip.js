
const nets = require('os').networkInterfaces();
console.log(JSON.stringify(nets, null, 2));
