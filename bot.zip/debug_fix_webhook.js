require('dotenv').config();
const axios = require('axios');

const INSTANCE = process.env.EVOLUTION_INSTANCE_NAME || 'FinanceBot';
const API_URL = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
const API_KEY = process.env.EVOLUTION_API_KEY;
// Use the PUBLIC url (host.docker.internal) for the webhook
const WEBHOOK_URL = process.env.WEBHOOK_PUBLIC_URL || 'http://192.168.1.18:4000';

async function fixWebhook() {
    console.log(`🔧 Fixing Webhook for instance: ${INSTANCE}`);
    console.log(`📡 API: ${API_URL}`);
    console.log(`🔗 Webhook Target: ${WEBHOOK_URL}/webhook/evolution`);

    try {
        const url = `${API_URL}/webhook/set/${INSTANCE}`;
        const body = {
            webhook: {
                enabled: true,
                url: `${WEBHOOK_URL}/webhook/evolution`,
                webhookUrl: `${WEBHOOK_URL}/webhook/evolution`,
                webhookByEvents: true,
                events: ["MESSAGES_UPSERT", "MESSAGES_UPDATE", "SEND_MESSAGE"]
            }
        };

        const res = await axios.post(url, body, {
            headers: { 'apikey': API_KEY }
        });

        console.log("✅ Success! Webhook response:", res.data);
    } catch (error) {
        console.error("❌ Failed:", error.response?.data || error.message);
    }

    // VERIFY
    try {
        console.log("🔍 Verifying stored config...");
        const res = await axios.get(`${API_URL}/webhook/find/${INSTANCE}`, {
            headers: { 'apikey': API_KEY }
        });
        console.log("📂 Current Webhook Config URL:", res.data.webhook.url);
        console.log("📂 Current Webhook Enabled:", res.data.webhook.enabled);
    } catch (e) {
        console.error("❌ Verify failed:", e.message);
    }
}

fixWebhook();
