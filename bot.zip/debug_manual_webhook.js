const axios = require('axios');

async function testWebhook() {
    try {
        console.log("🚀 Sending Fake Webhook to http://localhost:4000/webhook/evolution");
        const res = await axios.post('http://localhost:4000/webhook/evolution', {
            event: "MESSAGES_UPSERT",
            instance: "FinanceBot",
            data: {
                key: {
                    remoteJid: "5511999999999@s.whatsapp.net",
                    fromMe: false,
                    id: "TEST_MSG_123"
                },
                message: {
                    conversation: "Oi Teste Local"
                }
            }
        });
        console.log("✅ Response:", res.status, res.data);
    } catch (e) {
        console.error("❌ Failed:", e.message);
    }
}

testWebhook();
