require('dotenv').config();
const evolutionService = require('./src/services/evolutionService');

(async () => {
    console.log('Iniciando teste de envio...');
    const destino = '5521990149660@s.whatsapp.net'; // COLOQUE SEU N�MERO AQUI (com DDI e DDD)
    
    try {
        const result = await evolutionService.sendText(destino, '?? Teste de vida do Bot Financeiro!');
        console.log('Sucesso:', result);
    } catch (error) {
        console.error('Falha no envio:', error.response?.data || error.message);
    }
})();
