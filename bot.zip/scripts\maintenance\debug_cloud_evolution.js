const axios = require('axios');

const API_URL = 'http://evolution.mepoupay.app.br';
// Using the default key found in docker-compose.prod.yml. 
// If the user changed it in production, this might fail (401/403).
const API_KEY = '429683C4C977415CAAFCCE10F7D57E11';

async function checkInstances() {
    console.log(`🔍 Checking Evolution API at: ${API_URL}`);

    try {
        // 1. Fetch Instances
        const response = await axios.get(`${API_URL}/instance/fetchInstances`, {
            headers: { 'apikey': API_KEY }
        });

        const instances = response.data;
        console.log(`📦 Found ${instances.length} instances.`);

        if (instances.length === 0) {
            console.log("⚠️ No instances found. You need to create one.");
            return;
        }

        for (const instance of instances) {
            console.log(`\n---------------------------------------------------`);
            console.log(`📱 Instance: ${instance.name}`);
            console.log(`   Status: ${instance.connectionStatus}`);
            console.log(`   Owner: ${instance.ownerJid || 'Not connected'}`);

            // 2. Check Webhook Config for this instance
            try {
                const webhookRes = await axios.get(`${API_URL}/webhook/find/${instance.name}`, {
                    headers: { 'apikey': API_KEY }
                });

                const webhook = webhookRes.data;
                console.log(`   🪝 Webhook Config:`);
                console.log(`      Enabled: ${webhook.enabled}`);
                console.log(`      URL: ${webhook.webhookUrl || webhook.url}`);
                console.log(`      Events: ${webhook.events?.join(', ')}`);

                // Analysis
                if (!webhook.enabled) {
                    console.log(`   ❌ PROBLEM: Webhook is DISABLED.`);
                } else if (!webhook.webhookUrl?.includes('finance_bot_main')) {
                    console.log(`   ⚠️ POTENTIAL ISSUE: URL usually should be internal (http://finance_bot_main:3000...) if running in Docker.`);
                    console.log(`      Current URL: ${webhook.webhookUrl}`);
                } else {
                    console.log(`   ✅ Webhook looks correctly configured for Docker internal network.`);
                }

            } catch (err) {
                console.log(`   ⚠️ Could not fetch webhook details: ${err.message}`);
                // Verify if 404 means no webhook configured
                if (err.response && err.response.status === 404) {
                    console.log(`   ❌ Webhook likely NOT configured.`);
                }
            }
        }
        console.log(`\n---------------------------------------------------`);

    } catch (error) {
        console.error(`❌ Failed to connect to API: ${error.message}`);
        if (error.response) {
            console.error(`Status: ${error.response.status}`);
            console.error(`Data:`, error.response.data);
        }
    }
}

checkInstances();
