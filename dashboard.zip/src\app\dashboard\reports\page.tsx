import PlaceholderPage from '@/components/dashboard/PlaceholderPage';

export default function ReportsPage() {
    return <PlaceholderPage title="Relatórios Detalhados" />;
}
