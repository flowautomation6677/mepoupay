'use client';
import { Title, Card } from "@tremor/react";

export default function SettingsPage() {
    return <div className="p-4"><Title className="text-white mb-4">Ajustes Globais ⚙️</Title><Card className="glass-card ring-0 text-slate-400">Configurações do sistema...</Card></div>;
}
