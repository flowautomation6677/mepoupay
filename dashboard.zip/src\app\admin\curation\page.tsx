'use client';
import { Title, Card } from "@tremor/react";

export default function CurationPage() {
    return <div className="p-4"><Title className="text-white mb-4">Curadoria de Dados 🧠</Title><Card className="glass-card ring-0 text-slate-400">Ferramenta de anotação em desenvolvimento...</Card></div>;
}
