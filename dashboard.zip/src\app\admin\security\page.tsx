'use client';
import { Title, Card } from "@tremor/react";

export default function SecurityPage() {
    return <div className="p-4"><Title className="text-white mb-4">Logs de Segurança 🔐</Title><Card className="glass-card ring-0 text-slate-400">Módulo em construção...</Card></div>;
}
