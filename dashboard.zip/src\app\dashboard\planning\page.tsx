import PlaceholderPage from '@/components/dashboard/PlaceholderPage';

export default function PlanningPage() {
    return <PlaceholderPage title="Planejamento Financeiro" />;
}
