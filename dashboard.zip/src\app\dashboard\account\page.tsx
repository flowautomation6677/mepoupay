import PlaceholderPage from '@/components/dashboard/PlaceholderPage';

export default function AccountPage() {
    return <PlaceholderPage title="Minha Conta" />;
}
