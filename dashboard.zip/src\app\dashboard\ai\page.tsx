import PlaceholderPage from '@/components/dashboard/PlaceholderPage';

export default function AIPage() {
    return <PlaceholderPage title="Inteligência Me Poupey" />;
}
